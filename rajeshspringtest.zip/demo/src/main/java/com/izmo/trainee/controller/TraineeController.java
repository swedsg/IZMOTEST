package com.izmo.trainee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.izmo.trainee.entity.Trainee;
import com.izmo.trainee.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService service;
	
 @RequestMapping("/")
 public String getFirst()
 {
	 return "index";
 }
 
 @RequestMapping(value="/admin",method=RequestMethod.GET)
 public String admin()
 {
 return "admin";

 }
 @RequestMapping(value="/add", method = RequestMethod.GET)
 public String addTrainee()
 {
 return "addtrainee";
}
 @RequestMapping(value="/traineedetails", method = RequestMethod.POST)
 public String addDetails(@RequestParam("tid")String tid,@RequestParam("tname")String tname,@RequestParam("location")String location,@RequestParam("domain")String domain,Model model)
 {
	 Trainee tra=new Trainee();
	 tra.setTraineeId(Integer.parseInt(tid));
	 tra.setTraineeName(tname);
	 tra.setTraineeLocation(location);
	 tra.setTraineeDomain(domain);
	 service.addTrainee(tra);
	 model.addAttribute("msg", "One Trainee Reacord Added Successfully");
	return "admin";
	 
 }
 @RequestMapping(value="/delete", method = RequestMethod.GET)
 public String getDelete(Model model)
 {
	 List<Trainee> tra=service.getAllTrainee();
		model.addAttribute("std",tra);
 return "delete";
}
 @RequestMapping(value="/delete1",method=RequestMethod.GET)
 public String remove(@RequestParam("traineeid")String traineeid, Model model)
	{
//System.out.println(id);
		service.deleteTrainee(Integer.parseInt(traineeid));
	List<Trainee> tra=service.getAllTrainee();
	model.addAttribute("std", tra);
 return "admin";
	}
 @RequestMapping(value="/retrieve", method = RequestMethod.GET)
 public String retrieveTrainee()
 {
 return "retrieve";

 }
 @RequestMapping(value="/retrieve1", method = RequestMethod.POST)
 public String retrieveTrainee1(@RequestParam("tid")String tid, Model model)
 {

 Trainee t=service.retrieveTrainee(Integer.parseInt(tid));
 if(t!=null)
 {
 model.addAttribute("msg", t);
 }
 else {
 model.addAttribute("msg", "please enter the valid Trainee Id");
 }
 return "show";

 }
 @RequestMapping(value="/modify", method = RequestMethod.GET)
 public String modifyTrainee()
 {
 return "modify";
 }
 @RequestMapping(value="/update1", method = RequestMethod.POST)
 public String updateTrainee1(@RequestParam("tid")String id,@RequestParam("tname")String name,@RequestParam("location")String loc,@RequestParam("domain")String dom, Model model)
 {
 Trainee trainee=new Trainee();
 trainee.setTraineeId(Integer.parseInt(id));
 trainee.setTraineeName(name);
 trainee.setTraineeLocation(loc);
 trainee.setTraineeDomain(dom);

 boolean b=service.updateTrainee(trainee);
 if(b) {
 model.addAttribute("msg", "One Trainee Reacord updated Successfully");
 }
 else {
 model.addAttribute("msg", "Trainee not present");
 }
 return "update";

 }
	
}