package com.izmo.trainee.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;


import com.izmo.trainee.entity.Trainee;
import com.izmo.trainee.repository.TraineeRepo;


@Service
public class TraineeService {

	@Autowired
	TraineeRepo repository;
	public static List<Trainee> tra=new LinkedList();
	public void addTrainee(Trainee e)
	{
				
				repository.save(e);
		
	}
	public List<Trainee> getAllTrainee()
	{
		return repository.findAll();
	}
	public void deleteTrainee(int id)
	{
		repository.deleteById(id);
	}
	
	public Trainee retrieveTrainee(int id) {
		List<Trainee> t= repository.findAll();
		Trainee t2=new Trainee();
		for(Trainee t1:t)
		{
		if(t1.getTraineeId()==id)
		{
		t2.setTraineeId(id);
		t2.setTraineeName(t1.getTraineeName());
		t2.setTraineeLocation(t1.getTraineeLocation());
		t2.setTraineeDomain(t1.getTraineeDomain());
		}


		}

		return t2;
		}
	public boolean updateTrainee(Trainee trainee) {
		boolean b=false;
		List<Trainee> t=repository.findAll();
		for(Trainee t1:t)
		{
		if(t1.getTraineeId()==trainee.getTraineeId())
		{
		repository.save(trainee);
		b=true;
		}
		}
		return b;
		}
}
