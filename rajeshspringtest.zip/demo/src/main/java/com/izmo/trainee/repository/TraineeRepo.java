package com.izmo.trainee.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;


import com.izmo.trainee.entity.Trainee;

public interface TraineeRepo extends JpaRepository<Trainee,Integer> {

	
	
}
