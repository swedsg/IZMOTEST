package com.izmo.trainee2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.izmo.trainee2.model.Trainee2;

@Repository

public interface trainee2_repo  extends JpaRepository<Trainee2,Integer> {

}
