package com.izmo.trainee2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trainee2Application {

	public static void main(String[] args) {
		SpringApplication.run(Trainee2Application.class, args);
	}

}
