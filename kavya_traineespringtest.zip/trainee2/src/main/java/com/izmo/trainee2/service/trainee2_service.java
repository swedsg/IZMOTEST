package com.izmo.trainee2.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.trainee2.model.Trainee2;
import com.izmo.trainee2.repository.trainee2_repo;

@Service
public class trainee2_service {
	@Autowired
	trainee2_repo repository;
	
public void addTrainee(Trainee2 t) {
	repository.save(t);
}

public void deleteTrainee(int id) {
	repository.deleteById(id);
}

public List<Trainee2> getAlltrainee()
{
	return repository.findAll();
}

//public List<Trainee1> gettrainee(int id1)
//{
//	return repository.findById(id1);
//}

//public void updateTrainee(Trainee2 e)
//{
// List<Trainee2> e1=repository.findAll();
//		 repository.save(e); 
//}	
public Trainee2 retrieveTrainee(int id) {
List<Trainee2> t=repository.findAll();
Trainee2 t2=new Trainee2();
for(Trainee2 t1:t)
{
if(t1.getTrainee_id()==id)
{
t2.setTrainee_id(id);
t2.setTrainee_name(t1.getTrainee_name());
t2.setTrainee_location(t1.getTrainee_location());
t2.setTrainee_domain(t1.getTrainee_domain());
}


}

return t2;
}

public List<Trainee2> getAll() {
List<Trainee2> list=repository.findAll();

return list;
}

public boolean updateTrainee(Trainee2 trainee) {
boolean b=false;
List<Trainee2> t=repository.findAll();
for(Trainee2 t1:t)
{
if(t1.getTrainee_id()==trainee.getTrainee_id())
{
	repository.save(trainee);
b=true;
}
}
return b;
}
}
