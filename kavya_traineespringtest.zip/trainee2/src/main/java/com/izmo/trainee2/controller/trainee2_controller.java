package com.izmo.trainee2.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.izmo.trainee2.model.Trainee2;
import com.izmo.trainee2.repository.trainee2_repo;
import com.izmo.trainee2.service.trainee2_service;

@Controller
public class trainee2_controller {
@Autowired
trainee2_service service;
	@Autowired
	trainee2_repo repo;
	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String getPAge()
	{
		
		return "index";
	}
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public String getLogin(@RequestParam("name")String name,@RequestParam("pswd")String pswd,Model model,HttpSession session)
		{			
			if(name.equals("admin")&&pswd.equals("123"))
			{			
				return "admin";
			}			
			else
			{
				model.addAttribute("msg","invalid credentials!!");
				return "index";
			}
			
		}
	@RequestMapping(value = "/add",method = RequestMethod.GET)
	public String gettrainee()
	{	
		return "addTrainee";
	}
	
	@RequestMapping(value="/fetchadd", method = RequestMethod.POST)
	public String addTrainee1(@RequestParam("tid")String id,@RequestParam("tname")String name,@RequestParam("location")String loc,@RequestParam("domain")String dom, Model model)
	{
	Trainee2 trainee=new Trainee2();
	trainee.setTrainee_id(Integer.parseInt(id));
	trainee.setTrainee_name(name);
	trainee.setTrainee_location(loc);
	trainee.setTrainee_domain(dom);

	service.addTrainee(trainee);
	model.addAttribute("msg", "One Trainee Record Added Successfully");
	return "addTrainee";

	}
	@RequestMapping(value = "/delete",method = RequestMethod.GET)
	public String deltrainee()
	{	
		return "deletetrainee";
	}
	@RequestMapping(value = "/delete",method = RequestMethod.POST)
	public String gettrainee2(@RequestParam("tid")String id,Model model)
	{	service.deleteTrainee(Integer.parseInt(id));
	model.addAttribute("msg", "One Trainee Reacord deleted Successfully");
		return "deletetrainee";
	}
	@RequestMapping(value = "/view2",method = RequestMethod.GET)
	public String viewtrainee(Model model)
	{	
		List<Trainee2> traine=service.getAlltrainee();
	System.out.println(traine);
	model.addAttribute("emp",traine);
		return "view";
	}

	@RequestMapping(value="/retrivebyid1", method = RequestMethod.GET)
	public String retrieveTrainee()
	{
	return "retrive";

	}
	@RequestMapping(value="/retrieve1", method = RequestMethod.POST)
	public String retrieveTrainee1(@RequestParam("tid")String id, Model model)
	{

	Trainee2 t=service.retrieveTrainee(Integer.parseInt(id));
	System.out.println(t);
	if(t!=null)
	{
	model.addAttribute("msg", t);
	}
	else {
	model.addAttribute("msg", "please enter the valid Trainee Id");
	}
	return "retrivebyid";

	}

	@RequestMapping(value="/retriveall", method = RequestMethod.GET)
	public String retrieveallTrainee(Model model)
	{
	List<Trainee2> list=service.getAll();
	model.addAttribute("msg", list);
	return "retriveall";

	}
	@RequestMapping(value="/modify", method = RequestMethod.GET)
	public String modifyTrainee()
	{
	return "modifytrainee";
	}
	@RequestMapping(value="/update", method = RequestMethod.POST)
	public String updateTrainee1(@RequestParam("tid")String id,@RequestParam("tname")String name,@RequestParam("location")String loc,@RequestParam("domain")String dom, Model model)
	{
	Trainee2 trainee=new Trainee2();
	trainee.setTrainee_id(Integer.parseInt(id));
	trainee.setTrainee_name(name);
	trainee.setTrainee_location(loc);
	trainee.setTrainee_domain(dom);

	boolean b=service.updateTrainee(trainee);
	if(b) {
	model.addAttribute("msg", "One Trainee Reacord updated Successfully");
	}
	else {
	model.addAttribute("msg", "Trainee not present");
	}
	return "modifytrainee";

	}
}
