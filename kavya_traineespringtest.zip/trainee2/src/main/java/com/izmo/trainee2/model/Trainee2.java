package com.izmo.trainee2.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trainee2")
public class Trainee2 {
	
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private int trainee_id;
	
	@Column(name="trainee_name")
private String trainee_name;
	
	@Column(name="trainee_location")
private String trainee_location;
	
	@Column(name="trainee_domain")
private String trainee_domain;

	
	public int getTrainee_id() {
		return trainee_id;
	}

	public void setTrainee_id(int trainee_id) {
		this.trainee_id = trainee_id;
	}

	public String getTrainee_name() {
		return trainee_name;
	}

	public void setTrainee_name(String trainee_name) {
		this.trainee_name = trainee_name;
	}

	public String getTrainee_location() {
		return trainee_location;
	}

	public void setTrainee_location(String trainee_location) {
		this.trainee_location = trainee_location;
	}

	public String getTrainee_domain() {
		return trainee_domain;
	}

	public void setTrainee_domain(String trainee_domain) {
		this.trainee_domain = trainee_domain;
	}
	@Override
	public String toString() {
		return "Trainee [trainee_id=" + trainee_id + ", trainee_name=" + trainee_name + ", trainee_location="
				+ trainee_location + ", trainee_domain=" + trainee_domain + "]";
	}



}