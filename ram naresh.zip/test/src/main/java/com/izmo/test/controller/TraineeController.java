package com.izmo.test.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.test.main.Trainee;
import com.izmo.test.service.TraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	TraineeService sv;
	
	@RequestMapping("/")
	public String getIndex()
	{
		return "index";
	}
	
	@RequestMapping("/pF")
	public String getOps()
	{
		return "admin";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session)
	{
		session.removeAttribute("name");
		session.invalidate();
		return "index";
	}
	
	@RequestMapping(value = "/add",method = RequestMethod.GET)																
	public String getInsert()
	{
		return "insert";																								
	}
	
	@RequestMapping(value = "/create",method = RequestMethod.POST)
	public String getAdd(@RequestParam("id")int traineeId,@RequestParam("name")String traineeName,@RequestParam("dom")String traineeDomain,@RequestParam("loc")String traineeLocation, Model m)
	{
		Trainee t= new Trainee();
		t.setTraineeId(traineeId);
		t.setTraineeName(traineeName);
		t.setTraineeDomain(traineeDomain);
		t.setTraineeLocation(traineeLocation);
//		System.out.println(d);
		sv.addTrainee(t);																								
		m.addAttribute("msg","One Record Added");																	
		return "insert";
	}
	
	@RequestMapping(value = "/show",method = RequestMethod.GET)
	public String getShow(Model m)
	{
		List<Trainee> t=sv.showTrainee();																		
		System.out.println(t);																					
		m.addAttribute("t",t);																					
		return "display";
	}
	
	@RequestMapping("/processForm")
	public String getResult(@RequestParam("name")String name,@RequestParam("pswd")String pswd,Model m)
	{
		if(name.equalsIgnoreCase("admin") && pswd.equalsIgnoreCase("pswd"))
		return "admin";
		else if(name.equalsIgnoreCase("customer") && pswd.equalsIgnoreCase("pswd"))
			return "customer";
		else
		{
			m.addAttribute("msg","Invalid Credentials!!!");
			return "index";
		}	
	}
	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String getPAge()
	{
		return "index";
	}
	
	@RequestMapping(value = "/update",method = RequestMethod.GET)
	public String getPAge1()
	{
		return "update";
	}
	
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public String update(@RequestParam("id")String id, @RequestParam("name")String name, Model m)
	{
		Trainee t=new Trainee();
		t.setTraineeId(Integer.parseInt(id));
		t.setTraineeName(name);
		System.out.println(t);
		sv.updTrainee(t);
		return "update";
	}
	
	@RequestMapping(value = "/delete",method = RequestMethod.GET)
	public String delete(Model m)
	{
		List<Trainee> t=sv.showTrainee();
		System.out.println(t);
		m.addAttribute("t",t);
		return "delete";
	}
	
	@RequestMapping(value = "/remove",method = RequestMethod.GET)
	public String remove(@RequestParam("id")String id,Model m)
	{
		sv.delTrainee(Integer.parseInt(id));
		List<Trainee> t=sv.showTrainee();
		System.out.println(t);
		m.addAttribute("t",t);
		return "delete";
	} 
	
	@RequestMapping("/showbyid")
	public String showById2() {
		return "showById2";
		
	}
	
	@RequestMapping("/showbyid3")
	public String gotoDisplayPageById(@RequestParam("trainee_id") int traineeId,Model m) {
		m.addAttribute("t",sv.getTraineeById(traineeId));
		return "showById1";
	}
	
}
