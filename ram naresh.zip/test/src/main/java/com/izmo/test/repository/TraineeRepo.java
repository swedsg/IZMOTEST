package com.izmo.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.test.main.Trainee;

public interface TraineeRepo extends JpaRepository<Trainee,Integer> {

}
