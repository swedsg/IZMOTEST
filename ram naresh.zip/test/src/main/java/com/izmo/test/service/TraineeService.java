package com.izmo.test.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.test.main.Trainee;
import com.izmo.test.repository.TraineeRepo;


@Service
public class TraineeService {
	
	@Autowired
	TraineeRepo r1;
	
	public static List<Trainee> tr= new LinkedList<>();
	
		public void addTrainee(Trainee t) 
		{
			tr.add(t);
		}
		
		public void delTrainee(int id)
		{
			for(int i=0;i<tr.size();i++)
			{
				if(tr.get(i).getTraineeId()==id)
					tr.remove(i);
			}
			
		}
	
		public void updTrainee(Trainee t)
		{
			for(int i=0; i<tr.size(); i++) 
			{
				if(tr.get(i).getTraineeId()==t.getTraineeId())
				{
					tr.remove(i);	tr.add(t);
				}
			}
		}
		
		public List <Trainee> showTrainee()
		{
			return tr;
		}
		
		public Trainee getTraineeById(int traineeId) {
			return r1.getById(traineeId);
	      }
}
