package com.izmo.vyshnaviboilla.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.vyshnaviboilla.entity.Trainee;

public interface TraineeRepo extends JpaRepository<Trainee,Integer>{
        
}
