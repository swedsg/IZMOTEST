package com.izmo.springTest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.springTest.Service.TraineeService;
import com.izmo.springTest.model.Trainee;

@Controller
public class TraineeController {
	@Autowired
    TraineeService serv1;
	@RequestMapping("/")
	public String gotoLoginPage() {
		return "index";
	}
	@RequestMapping("/gototraineepage")
	public String gotoTraineePage(@RequestParam("username") String username,@RequestParam("password") String password) {
		if(username.equals("admin")&&password.equals("123"))
		{
			return "traineepage";
		}
		else {
			return "index";
		}
		
	}
	@RequestMapping("/gototraineeaddpage")
	public String gotoTraineeAddpage() {
		return "traineeaddpage";
	}
	@RequestMapping("/addtraineedata")
	public String addTraineeData(@ModelAttribute Trainee t) {
		serv1.addTrainee(t);
		 return "traineepage";
	}
	@RequestMapping("/gotodeletepage")
	public String gotoDeleteTraineePage() {
		return "traineedeletepage";
	}
	@RequestMapping("/deletetraineedate")
	public String deleteTraineeData(@RequestParam("trainee_id") String trainee_id) {
		 serv1.deleteTrainee(Integer.parseInt(trainee_id));
		 return "traineepage";
	}
	@RequestMapping("/gotoupdatepage")
	public String gotoUpdataPage() {
		return "updatepage";
	}
	@RequestMapping("/gototraineeupdatapage")
	public String gotoTraineeUpdatePage(@RequestParam("trainee_id") String trainee_id,Model m) {
		m.addAttribute("traineedata",serv1.gettraineeById(Integer.parseInt(trainee_id)));
		return "traineeupdatepage";
	}
	@RequestMapping("/updatetraineedata")
	public String updateTraineeData(@ModelAttribute Trainee t) {
		serv1.addTrainee(t);
		 return "traineepage";
	}
	@RequestMapping("/gotoretrivepage")
	public String gotoRetrivepageById() {
		return "retrivepagebyid";
	}
	@RequestMapping("/gotodisplaypagebyid")
	public String gotoDisplayPageById(@RequestParam("trainee_id") String trainee_id,Model m) {
		m.addAttribute("traineedata",serv1.gettraineeById(Integer.parseInt(trainee_id)));
		return "traineedisplayepagebyid";
		
	}
	@RequestMapping("/displayaddtrainepage")
	public String displayAllTrainee(Model m) {
		m.addAttribute("alltrainee",serv1.getAllTrainee());
		return "displayalltrainee";
	}
}
