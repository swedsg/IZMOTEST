package com.izmo.springTest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.springTest.model.Trainee;

public interface TraineeRepo extends JpaRepository<Trainee,Integer>{
        
}
