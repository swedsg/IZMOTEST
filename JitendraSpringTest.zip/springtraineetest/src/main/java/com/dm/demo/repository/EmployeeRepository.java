package com.dm.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dm.demo.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Integer>{
	
	/*public int addEmployee(Employee e);
	public List<Employee> getAllEmployees();
	public int updateEmployee(Employee e);
	public int deleteEmployee(int id);*/

}
