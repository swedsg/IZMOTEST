package com.dm.demo.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="trainee")
public class Trainee {
@Id
private int id;
private String name;
	private String location;
private String domain;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getDomain() {
	return domain;
}
public void setDomain(String domain) {
	this.domain = domain;
}
@Override
public String toString() {
	return "Trainee [id=" + id + ", name=" + name + ", location=" + location + ", domain=" + domain + "]";
}
public Trainee() {
	super();
	// TODO Auto-generated constructor stub
}
public Trainee(int id, String name, String location, String domain) {
	super();
	this.id = id;
	this.name = name;
	this.location = location;
	this.domain = domain;
}

}

//@Entity
//public class Trainee {
//@Id
//@GeneratedValue(strategy = GenerationType.AUTO)
//private int id;
//
//private String name;
//
//private int salary;
//public int getId() {
//	return id;
//}
//public void setId(int id) {
//	this.id = id;
//}
//public String getName() {
//	return name;
//}
//public void setName(String name) {
//	this.name = name;
//}
//public int getSalary() {
//	return salary;
//}
//public void setSalary(int salary) {
//	this.salary = salary;
//}
//@Override
//public String toString() {
//	return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
//}
//
//}
