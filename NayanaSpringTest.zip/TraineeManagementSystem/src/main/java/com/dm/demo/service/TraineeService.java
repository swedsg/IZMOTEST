package com.dm.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.demo.model.Trainee;
import com.dm.demo.repository.TraineeRepository;

@Service
public class TraineeService {

	@Autowired
	TraineeRepository repository;

	public void deleteTrainee(int id) {
		repository.deleteById(id);
	}

	public void addTrainee(Trainee e) {

		repository.save(e);

	}

	public void updateTrainee(Trainee e) {
		repository.save(e);
	}

	public List<Trainee> getAllTrainees() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	public boolean update(Trainee emp) {
		boolean b = false;
		List<Trainee> emp1 = repository.findAll();
		for (Trainee e : emp1) {
			if (e.getId() == emp.getId()) {
				repository.save(emp);
				b = true;
			}
		}

		return b;

	}

	public void deleteById(int id) {
		repository.deleteById(id);

	}

	public Trainee retrieveTrainee(int id) {
		List<Trainee> t = repository.findAll();
		Trainee t2 = new Trainee();
		for (Trainee t1 : t) {
			if (t1.getId() == id) {
				t2.setId(id);
				t2.setName(t1.getName());
				t2.setLocation(t1.getLocation());
				t2.setDomain(t1.getDomain());
			}
		}
		return t2;
	}

}
