package com.dm.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.demo.model.Trainee;
import com.dm.demo.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService service;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String getPAge() {

		return "index";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String getInsert() {

		return "insert";
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String getAdd(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("location") String location, @RequestParam("domain") String domain, Model model) {
		Trainee e = new Trainee();
		e.setId(id);
		e.setName(name);
		e.setLocation(location);
		e.setDomain(domain);
		System.out.println(e);
		service.addTrainee(e);
		model.addAttribute("msg", "One Record Added");
		return "insert";
	}

	@RequestMapping("/show")
	public String getShow(Model model) {
		List<Trainee> employees = service.getAllTrainees();
		System.out.println(employees);
		model.addAttribute("emp", employees);
		return "display";
	}

	@RequestMapping("/processForm")
	public String getResult(@RequestParam("name") String name, @RequestParam("pswd") String pswd, Model model) {
		if (name.equalsIgnoreCase("admin") && pswd.equalsIgnoreCase("pswd"))
			return "admin";

		else {
			model.addAttribute("msg", "Invalid Credencials!!!");
			return "index";
		}
	}

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String getPAge1() {

		return "update";
	}

	@RequestMapping(value = "/update1", method = RequestMethod.POST)
	public String getupdate(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("location") String location, @RequestParam("domain") String domain, Model model) {
		Trainee emp = new Trainee();
		emp.setId(id);
		emp.setName(name);
		emp.setLocation(location);
		emp.setDomain(domain);
		boolean b = service.update(emp);
		if (b) {
			model.addAttribute("msg", "data updated successfully");
		} else {
			model.addAttribute("msg", "Employee not found");
		}
		return "update";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String getPAge2(Model model) {
		List<Trainee> emp = service.getAllTrainees();
		model.addAttribute("msg", emp);
		return "delete";
	}

	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	public String getPAge21(@RequestParam("id") String id, Model model) {
		service.deleteById(Integer.parseInt(id));

		List<Trainee> emp = service.getAllTrainees();
		model.addAttribute("msg", emp);
		return "delete";

	}
	@RequestMapping(value="/retrieve1", method = RequestMethod.GET)
	public String retrieveTrainee()
	{
	return "retrieve";

	}
	@RequestMapping(value="/retrieve2", method = RequestMethod.POST)
	public String retrieveTrainee1(@RequestParam("id")String id, Model model)
	{

	Trainee t=service.retrieveTrainee(Integer.parseInt(id));
	System.out.println(t);
	if(t!=null)
	{
	model.addAttribute("msg", t);
	}
	else {
	model.addAttribute("msg", "please enter the valid Trainee Id");
	}
	return "retrieveatrainee";

	}
}
