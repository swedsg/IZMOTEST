package com.izmo.Trainee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraineeApplicationTests {

	@Test
	void contextLoads() {
	}

}
