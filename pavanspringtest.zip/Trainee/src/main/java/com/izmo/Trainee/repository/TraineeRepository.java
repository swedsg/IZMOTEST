package com.izmo.Trainee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.izmo.Trainee.model.Trainee;

@Repository
public interface TraineeRepository extends JpaRepository<Trainee, Integer>{

}