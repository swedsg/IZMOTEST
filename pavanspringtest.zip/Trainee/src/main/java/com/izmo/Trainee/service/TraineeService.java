package com.izmo.Trainee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.Trainee.model.Trainee;
import com.izmo.Trainee.repository.TraineeRepository;

@Service
public class TraineeService {

	@Autowired
	TraineeRepository traineeRepo;
	public boolean deleteTrainee(int id) {
		boolean b=false;
		List<Trainee> t=traineeRepo.findAll();
		for(Trainee t1:t)
		{
		if(t1.getTraineeId()==id)
		{
			traineeRepo.deleteById(id);
		b=true;
		}
		}
		return b;


		}
	
	public Trainee retrieveTrainee(int id) {
		List<Trainee> t=traineeRepo.findAll();
		Trainee t2=new Trainee();
		for(Trainee t1:t)
		{
		if(t1.getTraineeId()==id)
		{
		t2.setTraineeId(id);
		t2.setTraineeName(t1.getTraineeName());
		t2.setTraineeLocation(t1.getTraineeLocation());
		t2.setTraineeDomain(t1.getTraineeDomain());
		}


		}

		return t2;
		}

	
	public void addTrainee(Trainee trainee) {
		traineeRepo.save(trainee);
	}

	public boolean updateTrainee(Trainee trainee) {
		Optional<Trainee> list = traineeRepo.findById(trainee.getTraineeId());
		if (list.isPresent()) {
			traineeRepo.save(trainee);
			return true;
		} else {
			return false;
		}
	}

	public List<Trainee> getAllTrainees() {
		return traineeRepo.findAll();
	}
}
