package com.izmo.Trainee.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.Trainee.model.Trainee;
import com.izmo.Trainee.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService service;

	@RequestMapping("/")
	public String getIndex() {
		return "index";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("name");
		session.invalidate();
		return "index";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestParam("uname") String uname, @RequestParam("pswd") String pswd, Model model,
			HttpSession session) {
		if (uname.equals("admin") && pswd.equals("pwd123")) {
			session.setAttribute("name", "admin");
			return "tms";
		} else {
			model.addAttribute("msg", "invalid credentials!!");
			return "index";
		}
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String getInsert() {
		return "add";
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String add(@RequestParam("id") String traineeId, @RequestParam("name") String traineeName,
			@RequestParam("location") String traineeLocation, @RequestParam("domain") String traineeDomain,
			Model model) {
		Trainee trainee = new Trainee();
		trainee.setTraineeId(Integer.parseInt(traineeId));
		trainee.setTraineeName(traineeName);
		trainee.setTraineeLocation(traineeLocation);
		trainee.setTraineeDomain(traineeDomain);
		System.out.println(trainee);
		service.addTrainee(trainee);
		model.addAttribute("msg", "One Trainee Record Added Successfully");
		return "add";
	}

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String update() {
		return "update";
	}

	@RequestMapping(value = "/update1", method = RequestMethod.POST)
	public String update(@RequestParam("id") String traineeId, @RequestParam("name") String traineeName,
			@RequestParam("location") String traineeLocation, @RequestParam("domain") String traineeDomain,
			Model model) {
		Trainee trainee = new Trainee();
		trainee.setTraineeId(Integer.parseInt(traineeId));
		trainee.setTraineeName(traineeName);
		trainee.setTraineeLocation(traineeLocation);
		trainee.setTraineeDomain(traineeDomain);
		System.out.println(trainee);
		if(service.updateTrainee(trainee))
			model.addAttribute("msg", "One Trainee Record Modified Successfully");
		else
			model.addAttribute("msg", "No Trainee Record found with given Trainee ID");
		return "update";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String delete(Model model) {
		List<Trainee> trainees = service.getAllTrainees();
		System.out.println(trainees);
		model.addAttribute("trainee", trainees);
		return "delete";
	}

	@RequestMapping(value = "/remove", method = RequestMethod.GET)
	public String delete(@RequestParam("id") String id, Model model) {
		service.deleteTrainee(id);
		List<Trainee> trainees = service.getAllTrainees();
		model.addAttribute("trainee", trainees);
		return "delete";
	}

	@RequestMapping(value = "/showall", method = RequestMethod.GET)
	public String getAll(Model model) {
		List<Trainee> trainees = service.getAllTrainees();
		System.out.println(trainees);
		model.addAttribute("trainee", trainees);
		return "display";
	}

	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public String retrieveTrainee() {
		return "displayall";

	}

	@RequestMapping(value = "/retreive1", method = RequestMethod.POST)
	public String retrieveTrainee1(@RequestParam("id") String id, Model model) {
		Trainee trainee = service.getOneTrainee(Integer.parseInt(id));
		if (trainee != null) {
			model.addAttribute("trainee", trainee);
		} else {
			model.addAttribute("trainee", "please enter the valid Trainee Id");
		}
		return "displayone";

	}
}