package com.izmo.Trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.Trainee.model.Trainee;
import com.izmo.Trainee.repository.TraineeRepository;

@Service
public class TraineeService {

	@Autowired
	TraineeRepository traineeRepo;

	public void deleteTrainee(String id) {
		traineeRepo.deleteById(Integer.parseInt(id));
	}

	public void addTrainee(Trainee trainee) {
		traineeRepo.save(trainee);
	}

	public boolean updateTrainee(Trainee trainee) {
		boolean flag = false;
		List<Trainee> trainees = traineeRepo.findAll();
		for (Trainee t1 : trainees) {
			if (t1.getTraineeId() == trainee.getTraineeId()) {
				traineeRepo.save(trainee);
				flag = true;
			}
		}
		return flag;
	}

	public List<Trainee> getAllTrainees() {
		return traineeRepo.findAll();
	}

	public Trainee getOneTrainee(int id) {
		List<Trainee> trainees = traineeRepo.findAll();
		Trainee trainee = new Trainee();
		for (Trainee t : trainees) {
			if (t.getTraineeId() == id) {
				trainee.setTraineeId(id);
				trainee.setTraineeName(t.getTraineeName());
				trainee.setTraineeLocation(t.getTraineeLocation());
				trainee.setTraineeDomain(t.getTraineeDomain());
			}
		}
		return trainee;
	}
}
