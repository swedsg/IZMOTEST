package com.izmo.vyshnaviboilla.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.vyshnaviboilla.entity.Trainee;
import com.izmo.vyshnaviboilla.repositories.TraineeRepo;

@Service
public class TraineeService {
	@Autowired
	TraineeRepo repo1;
      public void addTrainee(Trainee t) {
    	  repo1.save(t);
      }
      public void deleteTrainee(int trainee_id) {
    	  repo1.deleteById(trainee_id);
      }
      public Trainee gettraineeById(int trainee_id) {
    	  return repo1.getById(trainee_id);
      }
      public List<Trainee> getAllTrainee(){
    	  return repo1.findAll();
      }
}
