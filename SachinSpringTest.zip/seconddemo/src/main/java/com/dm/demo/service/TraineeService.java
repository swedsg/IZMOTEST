package com.dm.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.demo.model.Trainee;
import com.dm.demo.repository.TraineeRepository;

@Service
public class TraineeService {

	@Autowired
	TraineeRepository repository;
	
	public void deleteEmployee(int id)
	{
		repository.deleteById(id);
	}
	
	public void addEmployee(Trainee e)
	{
				
				repository.save(e);
		
	}
	
	public void updateEmployee(Trainee e)
	{
		repository.save(e);
	}			
		
	public List<Trainee> getAllEmployees()
		{
			return repository.findAll();
		}
//	public Optional<Trainee> findById(int id)
//	{
//		return repository.findById(id);
//	}
	 public Trainee gettraineeById(int trainee_id) {
   	  return  repository.getById(trainee_id);
     }
	public boolean update(Trainee emp) {
		boolean b=false;
 List<Trainee> emp1=repository.findAll();
 for(Trainee e:emp1)
 {
	 if(e.getId()==emp.getId())
	 {
		 repository.save(emp);
		 b=true;
	 }
 }
	 
		return b;
		 		
	}

	public void deleteById(int id) {
		repository.deleteById(id);
		
	}
	}

