package com.dm.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.demo.model.Trainee;
import com.dm.demo.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService service;
	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String getPAge()
	{
		
		return "index";
	}
	
	@RequestMapping(value = "/add",method = RequestMethod.GET)
	public String getInsert()
	{
		
		return "insert";
	}
	@RequestMapping(value = "/create",method = RequestMethod.POST)
	public String getAdd(@RequestParam("name")String name,@RequestParam("dom")String dom,@RequestParam("loc")String loc,Model model)
	{
		Trainee e=new Trainee();
		e.setName(name);
		e.setDomain(dom);
		e.setLocation(loc);
		System.out.println(e);
		service.addEmployee(e);
		model.addAttribute("msg","One Record Added");
		return "insert";
	}
	
	@RequestMapping(value = "/show",method = RequestMethod.GET)
	public String getShow(Model model)
	{
		List<Trainee> employees=service.getAllEmployees();
		System.out.println(employees);
		model.addAttribute("emp",employees);
		return "display";
	}
	@RequestMapping(value = "/show1",method = RequestMethod.POST)
	public String getShow1(Model model,@RequestParam("id")String ids)
	{
		int id=Integer.parseInt(ids);
		Trainee employees=service.gettraineeById(id);
		System.out.println(employees);
		model.addAttribute("emp",employees);
		
		return "dispone";
		
	}
	@RequestMapping("/processForm")
	public String getResult(@RequestParam("name")String name,@RequestParam("pswd")String pswd,Model model)
	{
		if(name.equalsIgnoreCase("admin") && pswd.equalsIgnoreCase("pswd"))
		return "admin";
		else if(name.equalsIgnoreCase("customer") && pswd.equalsIgnoreCase("pswd"))
			return "customer";
		else
		{
			model.addAttribute("msg","Invalid Credencials!!!");
			return "index";
		}	
	}
	
	@RequestMapping(value = "/update",method = RequestMethod.GET)
	public String getPAge1()
	{
		
		return "update";
	}
	
	@RequestMapping(value = "/update1",method = RequestMethod.POST)
	public String getupdate(@RequestParam("id")String id,@RequestParam("name")String name,@RequestParam("loc")String loc,@RequestParam("dom")String dom,Model model)
	{
		Trainee emp=new Trainee();
		emp.setId(Integer.parseInt(id));
		emp.setName(name);
		emp.setLocation(loc);
		emp.setDomain(dom);
		boolean b=service.update(emp);
		if(b)
		{
			model.addAttribute("msg", "data updated successfully");
		}
		else  {
			model.addAttribute("msg", "Employee not found");
		}
		return "update";
	}
	
	@RequestMapping(value = "/delete",method = RequestMethod.GET)
	public String getPAge2(Model model)
	{
		List<Trainee> emp=service.getAllEmployees();
		model.addAttribute("msg", emp);
		return "delete";
	}
	
	@RequestMapping(value = "/remove",method = RequestMethod.POST)
	public String getPAge21(@RequestParam("id")String id, Model model)
	{
		service.deleteById(Integer.parseInt(id));
		
		List<Trainee> emp=service.getAllEmployees();
		model.addAttribute("msg", emp);
		return "delete";
		
	}
	
	@RequestMapping("/retrive")
	public String getPage5() {
		return "retrive";
		
	}
	@RequestMapping("/return")
	public String getPage6() {
		return "admin";
		
	}
}
