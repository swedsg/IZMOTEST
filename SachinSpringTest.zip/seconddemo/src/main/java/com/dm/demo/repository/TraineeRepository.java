package com.dm.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dm.demo.model.Trainee;

public interface TraineeRepository extends JpaRepository<Trainee,Integer>{
	
	

}
