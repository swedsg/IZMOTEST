package com.dm.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.dm")
public class SeconddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeconddemoApplication.class, args);
	}

}
