package com.izmo.traineemanagementsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.traineemanagementsystem.entity.Trainee;
import com.izmo.traineemanagementsystem.repository.TraineeRepo;

@Service
public class TraineeService {

	@Autowired
	TraineeRepo tRepo;
	
	public void addTrainee(Trainee trainee) {
	 
		tRepo.save(trainee);
	}

	public boolean deleteTrainee(int id) {
		boolean b=false;
		List<Trainee> t=tRepo.findAll();
		for(Trainee t1:t)
		{
			if(t1.getTraineeId()==id)
			{
				tRepo.deleteById(id);
				b=true;
			}
		}
		return b;
		 
		
	}

	public Trainee retrieveTrainee(int id) {
		List<Trainee> t=tRepo.findAll();
		Trainee t2=new Trainee();
		for(Trainee t1:t)
		{ 
				 if(t1.getTraineeId()==id)
				 {
					 t2.setTraineeId(id);
					 t2.setTraineeName(t1.getTraineeName());
					 t2.setTraineeLocation(t1.getTraineeLocation());
					 t2.setTraineeDomain(t1.getTraineeDomain());
				 }
				 
		 
		}
		 
		return t2;
	}

	public List<Trainee> getAll() {
		List<Trainee> list=tRepo.findAll();
		 
		return list;
	}

	public boolean updateTrainee(Trainee trainee) {
	 boolean b=false;
		List<Trainee> t=tRepo.findAll();
		for(Trainee t1:t)
		{
			if(t1.getTraineeId()==trainee.getTraineeId())
			{
				 tRepo.save(trainee);
				b=true;
			}
		}
		return b;
	}

}
