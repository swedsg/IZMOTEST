package com.izmo.traineemanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.traineemanagementsystem.entity.Trainee;
import com.izmo.traineemanagementsystem.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService tService;
	
	@RequestMapping("/")
	public String login()
	{
		return "index";
		
	}
	@RequestMapping(value="/admin", method = RequestMethod.GET)
	public String admin()
	{
		return "admin";
		
	}
	@RequestMapping(value="/addtrainee", method = RequestMethod.GET)
	public String addTrainee()
	{
		return "addtrainee";
		
	}
	@RequestMapping(value="/addtrainee1", method = RequestMethod.POST)
	public String addTrainee1(@RequestParam("tid")String id,@RequestParam("tname")String name,@RequestParam("location")String loc,@RequestParam("domain")String dom, Model model)
	{
		Trainee trainee=new Trainee();
		trainee.setTraineeId(Integer.parseInt(id));
		trainee.setTraineeName(name);
		trainee.setTraineeLocation(loc);
		trainee.setTraineeDomain(dom);
		
		tService.addTrainee(trainee);
		model.addAttribute("msg", "One Trainee Reacord Added Successfully");
		return "addtrainee";
		
	}
	
	@RequestMapping(value="/delete", method = RequestMethod.GET)
	public String deleteTrainee()
	{
		return "delete";
		
	}
	@RequestMapping(value="/delete1", method = RequestMethod.POST)
	public String addTrainee1(@RequestParam("tid")String id, Model model)
	{
		boolean b=tService.deleteTrainee(Integer.parseInt(id));
		if(b)
		{
			model.addAttribute("msg", "One Trainee Reacord Deleted Successfully");
		}
		else {
			model.addAttribute("msg", "Please Enter the existing Trainee ID");
		}
		return "delete";
	
	}
	@RequestMapping(value="/retrieve", method = RequestMethod.GET)
	public String retrieveTrainee()
	{
		return "retrieve";
		
	}
	@RequestMapping(value="/retrieve1", method = RequestMethod.POST)
	public String retrieveTrainee1(@RequestParam("tid")String id, Model model)
	{

        Trainee t=tService.retrieveTrainee(Integer.parseInt(id));
	 if(t!=null)
	 {
		 model.addAttribute("msg", t);
	 }
	 else {
		 model.addAttribute("msg", "please enter the valid Trainee Id");
	}
		return "singletrainee";
	
	}
	
	@RequestMapping(value="/retrieveall", method = RequestMethod.GET)
	public String retrieveallTrainee(Model model)
	{
		List<Trainee> list=tService.getAll();
		model.addAttribute("msg", list);
		return "retrieveall";
		
	}
	@RequestMapping(value="/modify", method = RequestMethod.GET)
	public String modifyTrainee()
	{
		return "update";	
	}
	@RequestMapping(value="/update", method = RequestMethod.POST)
	public String updateTrainee1(@RequestParam("tid")String id,@RequestParam("tname")String name,@RequestParam("location")String loc,@RequestParam("domain")String dom, Model model)
	{
		Trainee trainee=new Trainee();
		trainee.setTraineeId(Integer.parseInt(id));
		trainee.setTraineeName(name);
		trainee.setTraineeLocation(loc);
		trainee.setTraineeDomain(dom);
		
		boolean b=tService.updateTrainee(trainee);
		if(b) {
		model.addAttribute("msg", "One Trainee Reacord updated Successfully");
		}
		else {
			model.addAttribute("msg", "Trainee not present");
		}
		return "update";
		
	}

}
