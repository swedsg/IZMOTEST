package com.izmo.traineemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraineeManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraineeManagementSystemApplication.class, args);
	}

}
